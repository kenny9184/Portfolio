# Part 1: YouTube User Analysis ----

# Load packages required for this session into library

library(vosonSML)
library(igraph)
install.packages("ggplot2")
library(ggplot2)


# Set up YouTube authentication variables

my_api_key <- "AIzaSyB1C4-RY8AKitoG_7lkGdAy1kmrh-jkKoA"


# Authenticate to YouTube and collect data

yt_auth <- Authenticate("youtube", apiKey = my_api_key)

#Videos in order: Laufey - From The Start (Official Music Video),
#Let You Break My Heart Again - Laufey & Philharmonia Orchestra (Official Audio)
#Laufey - Valentine (Official Audio)
#Laufey - Falling Behind (Official Audio)
#Laufey Playlist
#Laufey: Tiny Desk Concert

video_url <- c("https://www.youtube.com/watch?v=lSD_L-xic9o",
               "https://www.youtube.com/watch?v=NLphEFOyoqM",
               "https://www.youtube.com/watch?v=tyKu0uZS86Q",
               "https://www.youtube.com/watch?v=Ej8RhiSv2-4",
               "https://www.youtube.com/watch?v=nUALouCrfRw",
               "https://www.youtube.com/watch?v=avjI3_GIZBw")

yt_data <- yt_auth |> Collect(videoIDs = video_url,
                              maxComments = 750,
                              writeToFile = TRUE,
                              verbose = TRUE) # use 'verbose' to show download progress


# View collected YouTube data

View(yt_data)

authors <- yt_data$AuthorDisplayName
authors[1:10]

authors[duplicated(authors)]
table(authors[duplicated(authors)])

# Create actor network and graph from the data

yt_actor_network <- yt_data |> Create("actor")
yt_actor_graph <- yt_actor_network |> Graph()

plot(yt_actor_graph, vertex.label = "", vertex.size = 4, edge.arrow.size = 0.5)


# Write graph to file
# Make sure to set your working directory to where you want to save the file
# before you execute the next line

saveRDS(yt_actor_graph, file = "LaufeyYouTubeActor.rds")
write_graph(yt_actor_graph, file = "LaufeyYouTubeActor.graphml", format = "graphml")


# Run Page Rank algorithm to find important users

rank_yt_actor <- sort(page_rank(yt_actor_graph)$vector, decreasing=TRUE)
rank_yt_actor[1:30]


# Overwrite the 'name' attribute in your graph with the 'screen name' attribute
# to replace YouTube IDs with more meaningful names,
# then run the Page Rank algorithm again

V(yt_actor_graph)$name <- V(yt_actor_graph)$screen_name

rank_yt_actor <- sort(page_rank(yt_actor_graph)$vector, decreasing = TRUE)
rank_yt_actor[1:30] # <NA> because this is the original video
 

# Are the top page rank users also the ones who commented the most?

table(authors[duplicated(authors)])

# Calculate the number of unique actors in the dataset
num_unique_actors <- length(unique(yt_data$AuthorDisplayName))

# Print the result
print(num_unique_actors)

# Load required packages
library(ggplot2)

# Subset the data for actors 7th to 11th
actors <- names(rank_yt_actor)[7:11]
scores <- rank_yt_actor[7:11]

# Create a data frame for ggplot
data <- data.frame(
  Actor = actors,
  PageRankScore = scores
)

# Create the bar plot using ggplot2
ggplot(data, aes(x = Actor, y = PageRankScore)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  theme_minimal() +
  labs(title = "PageRank Scores for top 5 actors (excluding orignal poster)",
       x = "Actor",
       y = "PageRank Score") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
        axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)))



# Visualize distribution of comments per actor
actor_comment_counts <- table(yt_data$AuthorDisplayName)
hist(actor_comment_counts, 
     main = "Distribution of Comments per Actor", 
     xlab = "Number of Comments", 
     ylab = "Frequency")











# Part 2: Spotify artist analysis ----

# Load packages required for this session into library

library(spotifyr)
library(ggplot2)
library(ggridges)


# Set up authentication variables

app_id <- "1122d19fdc8048f9a8688243f0b7102e"
app_secret <- "ae065ca4844345f09a73d22083fd0f68"
token <- "1"


# Authentication for spotifyr package:

Sys.setenv(SPOTIFY_CLIENT_ID = app_id)
Sys.setenv(SPOTIFY_CLIENT_SECRET = app_secret)
access_token <- get_spotify_access_token()


# Get Spotify data on 'Laufey'

find_my_artist <- search_spotify("Laufey", type = "artist")
View(find_my_artist)


# Retrieve album data of artist

albums <- get_artist_albums("7gW0r5CkdEUMm42w9XpyZO", 
                            include_groups = c("album", "single", "appears_on", "compilation"))
View(albums)

songs <- get_album_tracks("1hmlhl74JfLyUqmqtCwvFb")
View(songs)


# Retrieve song data

song <- get_track_audio_features("29Gys08x2u3ZSERTe0WvbE")
View(song)


# Get audio features for 'Laufey'

audio_features <- get_artist_audio_features("7gW0r5CkdEUMm42w9XpyZO") # artist ID for Laufey
View(audio_features)

audio_features <- audio_features[!duplicated(audio_features$track_name), ]


# Plot happiness (valence) scores for each album

ggplot(audio_features, aes(x = valence, y = album_name)) +
  geom_density_ridges() +
  theme_ridges() +
  ggtitle("Happiness in Laufey Albums",
          subtitle = "Based on valence from Spotify's Web API")

# Plot danceability scores for each album

ggplot(audio_features, aes(x = danceability, y = album_name)) +
  geom_density_ridges() +
  theme_ridges() +
  ggtitle("Danceability in Laufey Albums",
          subtitle = "Based on danceability from Spotify's Web API")


# Retrieve information about Laufey' related artists

related_lf <- get_related_artists("7gW0r5CkdEUMm42w9XpyZO")
View(related_lf)


# Create a network of artists related to Laufey

edges <- c()
for (artist in related_lf$id){
  related <- get_related_artists(artist)
  artist_name <- get_artist(artist)$name
  for (relatedartist in related$name){
    edges <- append(edges, artist_name)
    edges <- append(edges, relatedartist)
  }
}
edges[1:10]


# Convert network to graph and save as external file

related_artists_graph <- graph(edges)

plot(related_artists_graph, vertex.label = "", vertex.size = 4, edge.arrow.size = 0.5)
write_graph(related_artists_graph, file = "RelatedArtists.graphml", format = "graphml")

library(VOSONDash)
runVOSONDash()




