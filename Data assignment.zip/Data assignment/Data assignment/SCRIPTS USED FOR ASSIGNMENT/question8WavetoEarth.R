library(vosonSML)
library(igraph)
library(ggplot2)
library(scales)

# Load your chosen network graph
wte_network_graph <- readRDS("WteYouTubeActor.rds")

# Inspect the graph object
length(V(wte_network_graph))
V(wte_network_graph)$name <- V(wte_network_graph)$screen_name
V(wte_network_graph)$name[1:20]

# Find all maximum components that are weakly connected
wte_comps <- components(wte_network_graph, mode = c("weak"))

wte_comps$no
wte_comps$csize
head(wte_comps$membership, n = 30)

# Get sub-graph with most members
wte_largest_comp <- which.max(wte_comps$csize)

wte_comp_subgraph <- wte_network_graph |> 
  induced_subgraph(vids = which(wte_comps$membership == wte_largest_comp))

# Degree Centrality
wte_top_degree <- sort(degree(wte_comp_subgraph, mode = "total"), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(wte_top_degree)) | names(wte_top_degree) == ""
names(wte_top_degree)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
wte_top_degree_df <- data.frame(Node = names(wte_top_degree), Degree = wte_top_degree)
wte_top_degree_df

# Plot Degree Centrality
ggplot(wte_top_degree_df, aes(x = reorder(Node, -Degree), y = Degree)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Wave To Earth Top 20 Nodes by Degree Centrality") +
  xlab("Node") +
  ylab("Degree") +
  scale_y_continuous(labels = comma)

# Closeness Centrality
wte_top_closeness <- sort(closeness(wte_comp_subgraph, mode = "total"), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(wte_top_closeness)) | names(wte_top_closeness) == ""
names(wte_top_closeness)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
wte_top_closeness_df <- data.frame(Node = names(wte_top_closeness), Closeness = wte_top_closeness)
wte_top_closeness_df

# Plot Closeness Centrality
ggplot(wte_top_closeness_df, aes(x = reorder(Node, -Closeness), y = Closeness)) +
  geom_bar(stat = "identity", fill = "darkorange") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Wave To Earth Top 20 Nodes by Closeness Centrality") +
  xlab("Node") +
  ylab("Closeness") +
  scale_y_continuous(labels = comma)

# Betweenness Centrality
wte_top_betweenness <- sort(betweenness(wte_comp_subgraph, directed = FALSE), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(wte_top_betweenness)) | names(wte_top_betweenness) == ""
names(wte_top_betweenness)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
wte_top_betweenness_df <- data.frame(Node = names(wte_top_betweenness), Betweenness = wte_top_betweenness)
wte_top_betweenness_df

# Plot Betweenness Centrality
ggplot(wte_top_betweenness_df, aes(x = reorder(Node, -Betweenness), y = Betweenness)) +
  geom_bar(stat = "identity", fill = "forestgreen") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Wave To Earth Top 20 Nodes by Betweenness Centrality") +
  xlab("Node") +
  ylab("Betweenness") +
  scale_y_continuous(labels = comma)

