# Load packages required for this session into library

library(vosonSML)
library(VOSONDash)
library(dplyr)
library(tidyr)
library(tidytext)
library(textclean)
library(tm)
library(ggplot2)
library(igraph)



# Part 1: YouTube Text Analysis ----

# View the YouTube comments data from the previous file
View(yt_data)

# Remove rows that have 'NA'
yt_data <- yt_data[complete.cases(yt_data), ]
View(yt_data)

# Extract comments from the data
comments <- yt_data$Comment

# Clean the text with help from the textclean package
clean_text <- comments |> 
  replace_url() |> 
  replace_html() |>
  replace_non_ascii() |> # ` vs '
  replace_word_elongation() |>
  replace_internet_slang() |>
  replace_contraction() |>
  removeNumbers() |> 
  removePunctuation() |> 
  replace_emoji() |> # optional
  replace_emoticon() # optional
# order matters!

clean_text[1:10]

# Convert clean_text vector into a document corpus (collection of documents)
text_corpus <- VCorpus(VectorSource(clean_text))

text_corpus[[1]]$content
text_corpus[[5]]$content

# Perform further pre-processing 
text_corpus <- text_corpus |>
  tm_map(content_transformer(tolower)) |> 
  tm_map(removeWords, stopwords(kind = "SMART")) |> 
  # tm_map(stemDocument) |> # optional
  tm_map(stripWhitespace)

text_corpus[[1]]$content
text_corpus[[5]]$content

# Transform corpus into a Document Term Matrix
doc_term_matrix <- DocumentTermMatrix(text_corpus)

# Sort words by total frequency across all documents
dtm_df <- as.data.frame(as.matrix(doc_term_matrix))
View(dtm_df)

freq <- sort(colSums(dtm_df), decreasing = TRUE)

head(freq, n = 10)

# Plot word frequency
word_frequ_df <- data.frame(word = names(freq), freq)
View(word_frequ_df)
write.csv(word_frequ_df, file = "wordfreq.csv")

ggplot(subset(word_frequ_df, freq > freq[11]), aes(x = reorder(word, -freq), y = freq)) +
  geom_bar(stat = "identity") + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  ggtitle("Word Frequency") + 
  xlab("Words") + 
  ylab("Frequency")





# Part 2: YouTube Word Co-Occurrence ----

# Convert clean text into a data frame
clean_df <- data.frame(clean_text)

# Tokenization - split text into bigrams (two neighboring words)
yt_bigrams <- clean_df |> 
  unnest_tokens(output = bigram, input = clean_text, token = "ngrams", n = 2)
View(yt_bigrams)


# Create a table of bigrams and their counts
yt_bigrams_table <- yt_bigrams |> 
  count(bigram, sort = TRUE) |> 
  separate(bigram, c("left", "right"))
View(yt_bigrams_table)


#  Remove stop words from bigrams
yt_bigrams_nostops <- yt_bigrams_table |> 
  anti_join(stop_words, join_by(left == word)) |> 
  anti_join(stop_words, join_by(right == word))
View(yt_bigrams_nostops)


# Remove rows with 'NA' values
yt_bigrams_nostops <- yt_bigrams_nostops[complete.cases(yt_bigrams_nostops), ]
View(yt_bigrams_nostops)


# Filter bigrams that occur at least twice
yt_bigrams_nostops <- yt_bigrams_nostops |> filter(n >= 2)
View(yt_bigrams_nostops)


# Create a semantic network graph
yt_bigram_graph <- graph_from_data_frame(yt_bigrams_nostops, directed = FALSE)
yt_bigram_graph

# Simplify the graph by removing loops and multiple edges
yt_bigram_graph <- simplify(yt_bigram_graph)
vcount(yt_bigram_graph)
ecount(yt_bigram_graph)

# Plot the bigram network graph
plot(yt_bigram_graph, vertex.size = 4, edge.arrow.size = 0.5)


# Save the graph to an external file
write_graph(yt_bigram_graph, file = "LaufeyYouTubeBigram.graphml", format = "graphml")
runVOSONDash()  

# Calculate PageRank for each term in the bigram network
rank_yt_bigram <- sort(page_rank(yt_bigram_graph)$vector, decreasing=TRUE)
rank_yt_bigram[1:10]

# Create a dataframe for plotting
df <- data.frame(term = names(rank_yt_bigram)[1:10], PageRank = rank_yt_bigram[1:10])

# Plotting the PageRank for the top 10 terms
ggplot(df, aes(x = term, y = PageRank)) +
  geom_bar(stat = "identity", fill = "red") +
  labs( x = "Term",
       y = "PageRank") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

