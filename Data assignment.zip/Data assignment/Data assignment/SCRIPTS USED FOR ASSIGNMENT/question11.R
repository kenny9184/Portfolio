# Decision Tree -----------------------------------------------------------

library(spotifyr)
library(C50)
library(caret)
library(e1071)
library(dplyr)

# Set up Spotify authentication variables

app_id <- "1122d19fdc8048f9a8688243f0b7102e"
app_secret <- "ae065ca4844345f09a73d22083fd0f68"
token <- "1"


# Authenticate to Spotify using the spotifyr package:

Sys.setenv(SPOTIFY_CLIENT_ID = app_id)
Sys.setenv(SPOTIFY_CLIENT_SECRET = app_secret)
access_token <- get_spotify_access_token()


# Get songs from laufey and their audio features

laufey_features <- get_artist_audio_features("laufey")
View(laufey_features)

data.frame(colnames(laufey_features))

laufey_features_subset <- laufey_features[ , 9:20]
View(laufey_features_subset)

# Get top 50 songs and their audio features

top50_features <- get_playlist_audio_features("spotify", "37i9dQZF1DXcBWIGoYBM5M")
View(top50_features)

data.frame(colnames(top50_features))

top50_features_subset <- top50_features[ , 6:17]
View(top50_features_subset)

top50_features_subset <- top50_features_subset |> rename(track_id = track.id)


# Add the 'islaufey' column (class variable) to each data frame
# to indicate which songs are by laufey and which are not

top50_features_subset["islaufey"] <- 0
laufey_features_subset["islaufey"] <- 1


# Remove any songs by laufey that appear in the top 50
# and combine the two data frames into one dataset

top50_features_nolaufey <- anti_join(top50_features_subset,
                                     laufey_features_subset,
                                     by = "track_id")
comb_data <- rbind(top50_features_nolaufey, laufey_features_subset)


# Format the dataset so that we can give it as input to a model:
# change the 'islaufey' column into a factor
# and remove the 'track_id' column

comb_data$islaufey <- factor(comb_data$islaufey)
comb_data <- select(comb_data, -track_id)


# Randomise the dataset (shuffle the rows)

comb_data <- comb_data[sample(1:nrow(comb_data)), ]


# Split the dataset into training and testing sets (80% training, 20% testing)

split_point <- as.integer(nrow(comb_data)*0.8)
training_set <- comb_data[1:split_point, ]
testing_set <- comb_data[(split_point + 1):nrow(comb_data), ]


# Train the decision tree model

dt_model <- train(islaufey~ ., data = training_set, method = "C5.0")


# Sample a single prediction (can repeat)

prediction_row <- 1 # MUST be smaller than or equal to training set size

if (tibble(predict(dt_model, testing_set[prediction_row, ])) ==
    testing_set[prediction_row, 12]){
  print(paste("Prediction is correct!", predict(dt_model, testing_set[prediction_row, ])))
} else {
  ("Prediction is wrong")
}


# Analyse the model accuracy with a confusion matrix

confusionMatrix(dt_model, reference = testing_set$islaufey)



