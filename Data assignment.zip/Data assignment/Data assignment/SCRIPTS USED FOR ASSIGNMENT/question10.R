# Sentiment & Emotion Analysis --------------------------------------------

# Load packages required for this session into library
library(tidyr)
library(tidytext)
library(textclean)
library(tm)
library(syuzhet)
library(ggplot2)

# Clean the text
clean_text <- yt_data$Comment |> # change 'comment' to 'Comment' for YouTube
  replace_url() |> 
  replace_html() |>
  replace_non_ascii() |>
  replace_word_elongation() |>
  replace_internet_slang() |>
  replace_contraction() |>
  removeNumbers() |> 
  removePunctuation()
View(yt_data)

# Assign sentiment scores to comments
sentiment_scores <- get_sentiment(clean_text, method = "afinn") |> sign()

sentiment_df <- data.frame(text = clean_text, sentiment = sentiment_scores)
View(sentiment_df)

# Convert sentiment scores to labels: positive, neutral, negative
sentiment_df$sentiment <- factor(sentiment_df$sentiment, levels = c(1, 0, -1),
                                 labels = c("Positive", "Neutral", "Negative")) 
View(sentiment_df)

# Plot sentiment classification

ggplot(sentiment_df, aes(x = sentiment)) +
  geom_bar(aes(fill = sentiment)) +
  scale_fill_brewer(palette = "RdGy") +
  labs(fill = "Sentiment") +
  labs(x = "Sentiment Categories", y = "Number of Comments") +
  ggtitle("Sentiment Analysis of Comments")

# Assign emotion scores to comments
emo_scores <- get_nrc_sentiment(clean_text)[ , 1:8]

emo_scores_df <- data.frame(clean_text, emo_scores)
write.csv(emo_scores_df, file = "emo_scores_df.csv")
View(emo_scores_df)

# Calculate proportion of emotions across all comments
emo_sums <- emo_scores_df[,2:9] |> 
  sign() |> 
  colSums() |> 
  sort(decreasing = TRUE) |> 
  data.frame() / nrow(emo_scores_df) 

names(emo_sums)[1] <- "Proportion" 
View(emo_sums)

# Plot emotion classification
ggplot(emo_sums, aes(x = reorder(rownames(emo_sums), Proportion),
                     y = Proportion,
                     fill = rownames(emo_sums))) +
  geom_col() +
  coord_flip()+
  guides(fill = "none") +
  scale_fill_brewer(palette = "Dark2") +
  labs(x = "Emotion Categories", y = "Proportion of Comments") +
  ggtitle("Emotion Analysis of Comments")


