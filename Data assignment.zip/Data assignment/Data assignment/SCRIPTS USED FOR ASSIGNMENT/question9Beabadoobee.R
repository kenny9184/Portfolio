# Load necessary libraries
library(vosonSML)
library(igraph)
library(VOSONDash)

# Load your chosen network graph
beabadoobee_network_graph <- readRDS("BeaYoutubeActor.rds")

# Transform into an undirected graph
beabadoobee_undir_network_graph <- as.undirected(beabadoobee_network_graph, mode = "collapse")

# Run Louvain algorithm
beabadoobee_louvain_comm <- cluster_louvain(beabadoobee_undir_network_graph)

# See sizes of communities
print(sizes(beabadoobee_louvain_comm))

# Assign community memberships to nodes
V(beabadoobee_undir_network_graph)$louvain_comm <- membership(beabadoobee_louvain_comm)

# Save the Louvain communities to a GraphML file
write_graph(beabadoobee_undir_network_graph, file = "beabadoobee_louvain_communities.graphml", format = "graphml")
cat("Louvain communities saved to beabadoobee_louvain_communities.graphml\n")

# Run Girvan-Newman (edge-betweenness) algorithm
beabadoobee_eb_comm <- cluster_edge_betweenness(beabadoobee_undir_network_graph)

# See sizes of communities
print(sizes(beabadoobee_eb_comm))

# Assign community memberships to nodes
V(beabadoobee_undir_network_graph)$girvan_newman_comm <- membership(beabadoobee_eb_comm)

# Save the edge-betweenness communities to a GraphML file
beabadoobee_eb_filename <- "beabadoobee_girvan_newman_communities.graphml"
write_graph(beabadoobee_undir_network_graph, file = beabadoobee_eb_filename, format = "graphml")
cat("Girvan-Newman communities saved to", beabadoobee_eb_filename, "\n")

# Check if the Girvan-Newman clustering is hierarchical
print(is_hierarchical(beabadoobee_eb_comm))

# Plot the Girvan-Newman dendrogram
beabadoobee_dendrogram_filename <- "beabadoobee_girvan_newman_dendrogram.png"
png(file = beabadoobee_dendrogram_filename)
plot_dendrogram(beabadoobee_eb_comm, main = "Girvan-Newman Dendrogram")
dev.off()
cat("Girvan-Newman dendrogram saved to", beabadoobee_dendrogram_filename, "\n")

runVOSONDash()
