# Load necessary libraries
library(vosonSML)
library(igraph)
library(VOSONDash)

# Load your chosen network graph
wte_network_graph <- readRDS("WteYoutubeActor.rds")

# Transform into an undirected graph
wte_undir_network_graph <- as.undirected(wte_network_graph, mode = "collapse")

# Run Louvain algorithm
wte_louvain_comm <- cluster_louvain(wte_undir_network_graph)

# See sizes of communities
print(sizes(wte_louvain_comm))

# Assign community memberships to nodes
V(wte_undir_network_graph)$louvain_comm <- membership(wte_louvain_comm)

# Save the Louvain communities to a GraphML file
write_graph(wte_undir_network_graph, file = "wte_louvain_communities.graphml", format = "graphml")
cat("Louvain communities saved to wte_louvain_communities.graphml\n")

# Run Girvan-Newman (edge-betweenness) algorithm
wte_eb_comm <- cluster_edge_betweenness(wte_undir_network_graph)

# See sizes of communities
print(sizes(wte_eb_comm))

# Assign community memberships to nodes
V(wte_undir_network_graph)$girvan_newman_comm <- membership(wte_eb_comm)

# Save the edge-betweenness communities to a GraphML file
wte_eb_filename <- "wte_girvan_newman_communities.graphml"
write_graph(wte_undir_network_graph, file = wte_eb_filename, format = "graphml")
cat("Girvan-Newman communities saved to", wte_eb_filename, "\n")

# Check if the Girvan-Newman clustering is hierarchical
print(is_hierarchical(wte_eb_comm))

# Plot the Girvan-Newman dendrogram
wte_dendrogram_filename <- "wte_girvan_newman_dendrogram.png"
png(file = wte_dendrogram_filename)
plot_dendrogram(wte_eb_comm, main = "Girvan-Newman Dendrogram")
dev.off()
cat("Girvan-Newman dendrogram saved to", wte_dendrogram_filename, "\n")

runVOSONDash()
