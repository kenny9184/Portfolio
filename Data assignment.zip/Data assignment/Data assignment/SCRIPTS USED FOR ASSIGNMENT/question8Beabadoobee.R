library(vosonSML)
library(igraph)
library(ggplot2)
library(scales)

# Load your chosen network graph
bea_network_graph <- readRDS("BeaYouTubeActor.rds")

# Inspect the graph object
length(V(bea_network_graph))
V(bea_network_graph)$name <- V(bea_network_graph)$screen_name
V(bea_network_graph)$name[1:20]

# Find all maximum components that are weakly connected
bea_comps <- components(bea_network_graph, mode = c("weak"))

bea_comps$no
bea_comps$csize
head(bea_comps$membership, n = 30)

# Get sub-graph with most members
bea_largest_comp <- which.max(bea_comps$csize)

bea_comp_subgraph <- bea_network_graph |> 
  induced_subgraph(vids = which(bea_comps$membership == bea_largest_comp))

# Degree Centrality
bea_top_degree <- sort(degree(bea_comp_subgraph, mode = "total"), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(bea_top_degree)) | names(bea_top_degree) == ""
names(bea_top_degree)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
bea_top_degree_df <- data.frame(Node = names(bea_top_degree), Degree = bea_top_degree)
bea_top_degree_df

# Plot Degree Centrality
ggplot(bea_top_degree_df, aes(x = reorder(Node, -Degree), y = Degree)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Beabadoobee Top 20 Nodes by Degree Centrality") +
  xlab("Node") +
  ylab("Degree") +
  scale_y_continuous(labels = comma)

# Closeness Centrality
bea_top_closeness <- sort(closeness(bea_comp_subgraph, mode = "total"), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(bea_top_closeness)) | names(bea_top_closeness) == ""
names(bea_top_closeness)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
bea_top_closeness_df <- data.frame(Node = names(bea_top_closeness), Closeness = bea_top_closeness)
bea_top_closeness_df
# Plot Closeness Centrality
ggplot(bea_top_closeness_df, aes(x = reorder(Node, -Closeness), y = Closeness)) +
  geom_bar(stat = "identity", fill = "darkorange") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Beabadoobee Top 20 Nodes by Closeness Centrality") +
  xlab("Node") +
  ylab("Closeness") +
  scale_y_continuous(labels = comma)

# Betweenness Centrality
bea_top_betweenness <- sort(betweenness(bea_comp_subgraph, directed = FALSE), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(bea_top_betweenness)) | names(bea_top_betweenness) == ""
names(bea_top_betweenness)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
bea_top_betweenness_df <- data.frame(Node = names(bea_top_betweenness), Betweenness = bea_top_betweenness)
bea_top_betweenness_df

# Plot Betweenness Centrality
ggplot(bea_top_betweenness_df, aes(x = reorder(Node, -Betweenness), y = Betweenness)) +
  geom_bar(stat = "identity", fill = "forestgreen") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("BeabadoobeeTop 20 Nodes by Betweenness Centrality") +
  xlab("Node") +
  ylab("Betweenness") +
  scale_y_continuous(labels = comma)

