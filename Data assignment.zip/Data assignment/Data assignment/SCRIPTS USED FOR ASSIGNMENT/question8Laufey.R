library(vosonSML)
library(igraph)
library(ggplot2)
library(scales)

# Load your chosen network graph
laufey_network_graph <- readRDS("LaufeyYouTubeActor.rds")

# Inspect the graph object
length(V(laufey_network_graph))
V(laufey_network_graph)$name <- V(laufey_network_graph)$screen_name
V(laufey_network_graph)$name[1:20]

# Find all maximum components that are weakly connected
laufey_comps <- components(laufey_network_graph, mode = c("weak"))

laufey_comps$no
laufey_comps$csize
head(laufey_comps$membership, n = 30)

# Get sub-graph with most members
laufey_largest_comp <- which.max(laufey_comps$csize)

laufey_comp_subgraph <- laufey_network_graph |> 
  induced_subgraph(vids = which(laufey_comps$membership == laufey_largest_comp))

# Degree Centrality
top_degree <- sort(degree(laufey_comp_subgraph, mode = "total"), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(top_degree)) | names(top_degree) == ""
names(top_degree)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
top_degree_df <- data.frame(Node = names(top_degree), Degree = top_degree)

# Plot Degree Centrality
ggplot(top_degree_df, aes(x = reorder(Node, -Degree), y = Degree)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Top 20 Nodes by Degree Centrality") +
  xlab("Node") +
  ylab("Degree") +
  scale_y_continuous(labels = comma)

# Closeness Centrality
top_closeness <- sort(closeness(laufey_comp_subgraph, mode = "total"), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(top_closeness)) | names(top_closeness) == ""
names(top_closeness)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
top_closeness_df <- data.frame(Node = names(top_closeness), Closeness = top_closeness)

# Plot Closeness Centrality
ggplot(top_closeness_df, aes(x = reorder(Node, -Closeness), y = Closeness)) +
  geom_bar(stat = "identity", fill = "darkorange") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Top 20 Nodes by Closeness Centrality") +
  xlab("Node") +
  ylab("Closeness") +
  scale_y_continuous(labels = comma)

# Betweeness Centrality
top_betweenness <- sort(betweenness(laufey_comp_subgraph, directed = FALSE), decreasing = TRUE)[1:20]

# Handle missing node names
missing_names <- is.na(names(top_betweenness)) | names(top_betweenness) == ""
names(top_betweenness)[missing_names] <- paste0("Node_", which(missing_names))

# Create data frame for visualization
top_betweenness_df <- data.frame(Node = names(top_betweenness), Betweenness = top_betweenness)

# Plot Betweenness Centrality
ggplot(top_betweenness_df, aes(x = reorder(Node, -Betweenness), y = Betweenness)) +
  geom_bar(stat = "identity", fill = "forestgreen") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1), 
        plot.title = element_text(hjust = 0.5, face = "bold"),
        axis.title.x = element_text(face = "bold"),
        axis.title.y = element_text(face = "bold")) +
  ggtitle("Top 20 Nodes by Betweenness Centrality") +
  xlab("Node") +
  ylab("Betweenness") +
  scale_y_continuous(labels = comma)

