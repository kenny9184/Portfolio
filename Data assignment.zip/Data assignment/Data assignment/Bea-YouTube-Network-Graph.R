library(vosonSML)
library(igraph)
library(dplyr)
library(textclean)
library(tidytext)
library(tidyr)
library(tm)


# YouTube Data Collection ------------------------------------------------------

# Set up YouTube authentication variables
my_api_key <- "AIzaSyB1C4-RY8AKitoG_7lkGdAy1kmrh-jkKoA"

# Authenticate to YouTube and collect data
bea_auth <- Authenticate("youtube", apiKey = my_api_key)

video_url <- c("https://www.youtube.com/watch?v=y1cBhJLNNXU",
               "https://www.youtube.com/watch?v=HwtEBQiuX-c",
               "https://www.youtube.com/watch?v=sTQNJT7OZew")

bea_data <- bea_auth |> Collect(videoIDs = video_url,
                                maxComments = 1000,
                                writeToFile = TRUE,
                                verbose = TRUE) # use 'verbose' to show download progress

# View collected YouTube data
View(bea_data)


# YouTube Actor Graph -----------------------------------------------------

# Create actor network 
bea_actor_network <- bea_data |> 
  Create("actor") |> 
  AddText(bea_data,
          repliesFromText = TRUE,
          verbose = TRUE) |> 
  AddVideoData(bea_auth,
               actorSubOnly = TRUE,
               verbose = TRUE)

# Create graph from the network and change IDs to screen names
bea_actor_graph <- bea_actor_network |> Graph()
bea_actor_graph
V(bea_actor_graph)$name <- V(bea_actor_graph)$screen_name
bea_actor_graph


# Save and write graph to file
saveRDS(bea_actor_graph, file = "BeaYouTubeActor.rds")
write_graph(bea_actor_graph, file = "BeaYouTubeActor.graphml", format = "graphml")


# YouTube Semantic Graph --------------------------------------------------

# Clean the text with help from the textclean package
bea_clean_text <- bea_data$Comment |> 
  replace_url() |> 
  replace_html() |>
  replace_non_ascii() |> # ` vs '
  replace_word_elongation() |>
  replace_internet_slang() |>
  replace_contraction() |>
  removeNumbers() |> 
  removePunctuation()  # |> 
  replace_emoji() |> # optional
  replace_emoticon() # optional

bea_clean_df <- data.frame(bea_clean_text)

# Tokenisation: split into bigrams (two neighbouring words)
bea_bigrams <- bea_clean_df |> unnest_tokens(output = bigram,
                                             input = bea_clean_text,
                                             token = "ngrams",
                                             n = 2)

bea_bigrams_table <- bea_bigrams |> 
  count(bigram, sort = TRUE) |> 
  separate(bigram, c("left", "right"))

bea_bigrams_nostops <- bea_bigrams_table |> 
  anti_join(stop_words, join_by(left == word)) |> 
  anti_join(stop_words, join_by(right == word))

# Remove rows that have 'NA'
bea_bigrams_nostops <- bea_bigrams_nostops[complete.cases(bea_bigrams_nostops), ]

# If you have lots of bigrams, keep only those that occur at least X times (here X is 2)
bea_bigrams_nostops <- bea_bigrams_nostops |> filter(n >= 2)

bea_bigram_graph <- graph_from_data_frame(bea_bigrams_nostops, directed = FALSE)

bea_bigram_graph <- simplify(bea_bigram_graph) # remove loops and multiple edges

# Save and write graph to file
saveRDS(bea_bigram_graph, file = "BeaYouTubeSemantic.rds")
write_graph(bea_bigram_graph, file = "BeaYouTubeSemantic.graphml", format = "graphml")
