<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProjectsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $industryPartnerIds = DB::table('users')->where('user_type', 'industry_partner')->pluck('id')->toArray();

        // Seed projects with user_id from industry partners
        foreach (range(1, 11) as $index) {
            DB::table('projects')->insert([
                'title' => "Project Title $index",
                'description' => "Project Description $index",
                'num_of_students' => rand(3, 6),
                'trimester' => rand(1, 3),
                'year' => rand(2023, 2024),
                'attachment' => 'images/x.png',
                'user_id' => $industryPartnerIds[array_rand($industryPartnerIds)],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        // DB::table('projects')->insert([
        //     'title' => 'Web Development Project',
        //     'description' => 'A project to develop a web application.',
        //     'num_of_students' => 5,
        //     'trimester' => 1,
        //     'year' => 2023,
        //     'user_id' => 1
        // ]);

        // DB::table('projects')->insert([
        //     'title' => 'Python Project',
        //     'description' => 'A project to with python.',
        //     'num_of_students' => 3,
        //     'trimester' => 2,
        //     'year' => 2023,
        //     'user_id' => 1
        // ]);

        // DB::table('projects')->insert([
        //     'title' => 'HTML intro',
        //     'description' => 'Join please.',
        //     'num_of_students' => 4,
        //     'trimester' => 3,
        //     'year' => 2024,
        //     'user_id' => 2
        // ]);

        // DB::table('projects')->insert([
        //     'title' => 'PHP refresher',
        //     'description' => 'Join please please.',
        //     'num_of_students' => 5,
        //     'trimester' => 2,
        //     'year' => 2023,
        //     'user_id' => 2
        // ]);
        }
    }
}
