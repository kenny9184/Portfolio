<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // Seed a teacher
        DB::table('users')->insert([
            'name' => 'John Doe',
            'email' => 'john.doe@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'teacher'
        ]);

        // Seed a student
        DB::table('users')->insert([
            'name' => 'Alice Johnson',
            'email' => 'alice.johnson@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'student',
            // 'gpa' => 3.5, 
            // 'role' => 'software_developer'
        ]);

        DB::table('users')->insert([
            'name' => 'Kanye West',
            'email' => 'Kanye@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'student',
            // 'gpa' => 4, 
            // 'role' => 'tester, software_developer'
        ]);

        DB::table('users')->insert([
            'name' => 'Fred Bob',
            'email' => 'fred@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'student',
            // 'gpa' => 3.5, 
            // 'role' => 'software_developer'
        ]);

        DB::table('users')->insert([
            'name' => 'Leo Messi',
            'email' => 'Leo@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'student',
            // 'gpa' => 4, 
            // 'role' => 'tester, software_developer'
        ]);

        DB::table('users')->insert([
            'name' => 'Drake Drizzy',
            'email' => 'drake@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'student',
            // 'gpa' => 3.5, 
            // 'role' => 'software_developer'
        ]);

        DB::table('users')->insert([
            'name' => 'Lebron James',
            'email' => 'lebron@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'student',
            // 'gpa' => 4, 
            // 'role' => 'tester, software_developer'
        ]);

        // Seed an industry partner
        DB::table('users')->insert([
            'name' => 'Elon Musk',
            'email' => 'Elon@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'industry_partner'
        ]);

        DB::table('users')->insert([
            'name' => 'John Smith',
            'email' => 'jon@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'industry_partner'
        ]);

        DB::table('users')->insert([
            'name' => 'Peter Williams',
            'email' => 'peter@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'industry_partner'
        ]);

        DB::table('users')->insert([
            'name' => 'Justine Francis',
            'email' => 'justine@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'industry_partner'
        ]);

        DB::table('users')->insert([
            'name' => 'Sam Lewis',
            'email' => 'Sam@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'industry_partner'
        ]);

        DB::table('users')->insert([
            'name' => 'Hannah Freeman',
            'email' => 'hannah@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'industry_partner'
        ]);

        DB::table('users')->insert([
            'name' => 'Kate Kennedy',
            'email' => 'kate@example.com',
            'password' => bcrypt('password'),
            'user_type' => 'industry_partner'
        ]);
    }
}
