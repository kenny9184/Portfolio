<?php

namespace Database\Factories;

use App\Models\Enrolment;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class EnrolmentFactory extends Factory
{
    protected $model = Enrolment::class;

    public function definition(): array
    {
        return [
            'user_id' => $this->faker->numberBetween(1, 10), // Assuming user IDs 1 to 10 exist
            'project_id' => $this->faker->numberBetween(1, 10), // Assuming project IDs 1 to 10 exist
            'justification' => $this->faker->sentence,
        ];
    }
}
