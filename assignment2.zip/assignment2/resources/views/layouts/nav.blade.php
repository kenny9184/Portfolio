<div class="wrapper">
    <div class="sidebar">
        <h2>WIL</h2>
        <ul>
            <li><a href="{{ url("/") }}" class="nav-link"><img class="navicon" src="{{ asset('images/home.png') }}">Home</a></li>
            <li><a href="{{ route('projects.list') }}" class="nav-link"><img class="navicon" src="{{ asset('images/list.png') }}">Projects List</a></li>
            <li><a href="{{ url("documentation") }}" class="nav-link"><img class="navicon" src="{{ asset('images/document.png') }}">Documentation</a></li>
            @if(auth()->check() && auth()->user()->user_type === 'industry_partner')
                <li><a href="{{ route('project.create') }}" class="nav-link"><img class="navicon" src="{{ asset('images/add.png') }}">Create project</a></li>
            @endif                 
            @auth
                <li>
                    <a href="{{ route('logout') }}" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <img class="navicon" src="{{ asset('images/logout.png') }}">Logout
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </li>
            @else
                <li><a href="{{ route('login') }}" class="nav-link"><img class="navicon" src="{{ asset('images/user.png') }}">Log in</a></li>
                @if (Route::has('register'))
                    <li><a href="{{ route('register') }}" class="nav-link"><img class="navicon" src="{{ asset('images/add.png') }}">Register</a></li>
                @endif
            @endauth
        </ul>
    </div>
</div>
