@extends('layouts.master')

@section('title', 'Projects List')

@section('content')
    <div class="wrapper">
        <div class="main_content">
            <div class="header">
                <div class="left-section">
                    List of Projects
                </div>
                <div class="right-section">
                    @auth
                        {{ ucfirst(str_replace('_', ' ', Auth::user()->user_type)) }}: {{ Auth::user()->name }}
                    @endauth
                </div>
            </div>
            <div class="info">
                <div class="list">
                @foreach ($projectsByOffering as $offering => $projects)
    <h2>{{ $offering }}</h2>

    <ul class="project-group">
        @foreach ($projects as $projectCollection)
            @foreach ($projectCollection as $project)
                <li class="post-item">
                    <a href="{{ route('projects.show', ['project' => $project->id]) }}">
                        <h3>{{ $project->title }}</h3>
                    </a>
                </li>
            @endforeach
        @endforeach
    </ul>
@endforeach

                </div>
            </div>
        </div>
    </div>
@endsection
