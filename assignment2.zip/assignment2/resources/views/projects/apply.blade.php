@extends('layouts.master')

@section('title', 'Apply for Project')

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            <div class="left-section">
                Application for {{$project->title}}
            </div>
            <div class="right-section">
                @auth
                    {{ ucfirst(str_replace('_', ' ', Auth::user()->user_type)) }}: {{ Auth::user()->name }}
                @endauth
            </div>
        </div>
        <div class="info">
            <form method="post" action="{{ route('projects.apply', ['project' => $project->id]) }}">
                @csrf
                <div class="form-group">
                    <label for="justification">Justification:</label>
                    <textarea id="justification" name="justification" rows="4" cols="50" required placeholder="Why do you want to work on this project?"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Submit Application</button>
                </div>
            </form>

            @if(session('error'))
                <div id="error-alert" class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif


            <div class="post-actions">
                <a class="action-link" href="{{route('projects.show',['project' => $project->id])}}">
                    <img src="{{ asset('images/back.png') }}" alt="back">
                    Back
                </a>
            </div>
        </div>
    </div>
</div>
@endsection