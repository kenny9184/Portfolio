@extends('layouts.master')

@section('title', 'Create Project')

@section('content')
    <div class="wrapper">
        <div class="main_content">
            <div class="header">
                <div class="left-section">
                    Create Project
                </div>
                <div class="right-section">
                    @auth
                        {{ ucfirst(str_replace('_', ' ', Auth::user()->user_type)) }}: {{ Auth::user()->name }}
                    @endauth
                </div>
            </div>
            <div class="info">
                <form action="{{ route('projects.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf

                    <div class="form-group">
                        <label class="label" for="title">Title:</label>
                        <input class="input" type="text" id="title" name="title" value="{{ old('title') }}" required>
                        @error('title')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="description">Description:</label>
                        <textarea class="input" id="description" name="description" required>{{ old('description') }}</textarea>
                        @error('description')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="num_of_students">Number of Students:</label>
                        <input class="input" type="number" id="num_of_students" name="num_of_students" value="{{ old('num_of_students') }}" required>
                        @error('num_of_students')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="year">Year:</label>
                        <input class="input" type="number" id="year" name="year" value="{{ old('year') }}" required>
                        @error('year')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="trimester">Trimester:</label>
                        <input class="input" type="number" id="trimester" name="trimester" value="{{ old('trimester') }}" required>
                        @error('trimester')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        @if (auth()->check() && auth()->user()->user_type === 'industry_partner')
                            <div class="form-group">
                                <label class="label" for="attachment">Attachment (Image or PDF):</label>
                                <input type="file" name="attachment" accept="image/*, application/pdf" multiple>
                                @error('attachment')
                                    <p class="error-message">{{ $message }}</p>
                                @enderror
                            </div>
                        @endif
                    </div>

                    <button type="submit" class="button">Create Project</button>
                </form>
            </div>
        </div>
    </div>
@endsection
