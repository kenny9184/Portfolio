@extends('layouts.master')

@section('title', 'Edit Project')

@section('content')
    <div class="wrapper">
        <div class="main_content">
            <div class="header">
                <div class="left-section">
                    Edit: {{$project->title}}
                </div>
                <div class="right-section">
                    @auth
                        {{ ucfirst(str_replace('_', ' ', Auth::user()->user_type)) }}: {{ Auth::user()->name }}
                    @endauth
                </div>
            </div>
            <div class="info">
                <form action="{{ route('projects.update', ['project' => $project->id]) }}" method="POST">
                    @csrf
                    @method('PATCH')

                    <div class="form-group">
                        <label class="label" for="title">Title:</label>
                        <input class="input" type="text" id="title" name="title" value="{{ old('title', $project->title) }}" required>
                        @error('title')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="description">Description:</label>
                        <textarea class="input" id="description" name="description" required>{{ old('description', $project->description) }}</textarea>
                        @error('description')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="num_of_students">Number of Students:</label>
                        <input class="input" type="number" id="num_of_students" name="num_of_students" value="{{ old('num_of_students', $project->num_of_students) }}" required>
                        @error('num_of_students')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="year">Year:</label>
                        <input class="input" type="number" id="year" name="year" value="{{ old('year', $project->year) }}" required>
                        @error('year')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label class="label" for="trimester">Trimester:</label>
                        <input class="input" type="number" id="trimester" name="trimester" value="{{ old('trimester', $project->trimester) }}" required>
                        @error('trimester')
                            <p class="error-message">{{ $message }}</p>
                        @enderror
                    </div>

                    <button type="submit" class="button">Update Project</button>
                </form>
            </div>
        </div>
    </div>
@endsection
