@extends('layouts.master')

@section('title', $project->title . ' Details')

@section('content')
    <div class="wrapper">
        <div class="main_content">
            <div class="header">
                <div class="left-section">
                    {{ $project->title }} Details
                </div>
                <div class="right-section">
                    @auth
                        {{ ucfirst(str_replace('_', ' ', Auth::user()->user_type)) }}: {{ Auth::user()->name }}
                    @endauth
                </div>
            </div>
            <div class="info">
                <div class="project-details">
                    <h4>Description: {{ $project->description }}</h4><br>
                    <h4>Number of Students: {{ $project->num_of_students }}</h4><br>
                    <h4>Year: {{ $project->year }}</h4><br>
                    <h4>Trimester: {{ $project->trimester }}</h4><br>
                    <h4>Offered by: {{ $project->user->name }}</h4><br>
                </div>
                <div class="attachments">
                    <h2>Attachments</h2>

                    @if ($attachments->count() > 0)
                        @foreach ($attachments as $attachment)
                            @if ($attachment->type === 'image')
                                <img src="{{ asset($attachment->path) }}" alt="Project Image">
                            @elseif ($attachment->type === 'pdf')
                                <a href="{{ route('attachments.download', ['attachment' => $attachment->id]) }}" target="_blank">Download PDF</a>
                            @endif
                        @endforeach
                    @else
                        <p>No attachments available for this project.</p>
                    @endif
                </div>
                {{-- Applied Students Section --}}
                <div class="applied-students">
                    <h2>Applied Students</h2>
                    @if($project->studentProjects && $project->studentProjects->count() > 0)
                        @foreach ($project->studentProjects as $student)
                            <div class="applied-student">
                                <h4>{{ $student->name }}</h4>
                                <h5>Justification: {{ $student->pivot->justification }}</h5>
                            </div>
                        @endforeach
                    @else
                        <p>No students have applied for this project.</p>
                    @endif
                </div>
                @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
                {{-- Post Actions Section --}}
                <div class="post-actions">
                    @auth
                        @if (auth()->user()->user_type === 'student')
                            <a class="action-link" href="{{ route('projects.apply', ['project' => $project->id]) }}">
                                <img class="navicon" src="{{ asset('images/apply.png') }}" alt="Apply">
                                Apply for this project
                            </a>
                        @endif
                    @endauth
                    <br>
                    <a class="action-link" href="{{ route('users.show', ['user' => $project->user_id]) }}">
                        <img class="navicon" src="{{ asset('images/back.png') }}" alt="Back">
                        Back
                    </a>
                    @if (auth()->check() && auth()->user()->user_type === 'industry_partner' && $project->user_id === auth()->user()->id)
                        <a class="action-link edit-btn" href="{{ route('projects.edit', ['project' => $project->id]) }}">
                            <img class="navicon" src="{{ asset('images/edit.png') }}" alt="Edit">
                            Edit project
                        </a>
                        @foreach ($attachments as $attachment)
                            @if ($attachment->type === 'image')
                                <img src="{{ asset($attachment->path) }}" alt="Project Image">
                            @elseif ($attachment->type === 'pdf')
                                <a href="{{ route('attachments.download', ['attachment' => $attachment->id]) }}" target="_blank">Download PDF</a>
                            @endif
                        @endforeach

                    <form action="{{ url("project/$project->id") }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="action-link delete-btn">
                            <img class="navicon" src="{{ asset('images/delete.png') }}" alt="Delete">
                            Delete project
                        </button>
                    </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection

