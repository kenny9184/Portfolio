@extends('layouts.master')

@section('title', 'Home')

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            <div class="left-section">
                List of Industry Partners
            </div>
            <div class="right-section">
                @auth
                    {{ ucfirst(str_replace('_', ' ', Auth::user()->user_type)) }}: {{ Auth::user()->name }}
                @endauth
            </div>
        </div>
        <div class="info">
            <div class="list">
                <ul class="post-list">
                    @foreach ($users as $user)
                    <li class="post-item">
                        <a href="user/{{$user->id}}"><h2>{{$user->name}}</h2> 
                        </a>
                    </li>
                    @endforeach
                </ul>
                {{$users->links()}}
            </div>
        </div>
    </div>
</div>
@endsection



