@extends('layouts.master')

@section('title', $user->name . ' Projects')

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            <div class="left-section">
                {{ $user->name }}'s Projects
            </div>
            <div class="right-section">
                @auth
                    {{ ucfirst(str_replace('_', ' ', Auth::user()->user_type)) }}: {{ Auth::user()->name }}
                @endauth
            </div>
        </div>
        <div class="info">
            <h2>Email: {{ $user->email }}</h2><br>
            <div class="list">
                <ul class="post-list">
                    @foreach ($user->projects as $project)
                        <li class="post-item">
                            <a href="{{ route('projects.show', ['project' => $project->id]) }}">
                                <h2>{{ $project->title }}</h2>
                            </a>
                        </li>
                    @endforeach
                </ul>
                <div class="post-actions">
                    <a class="action-link" href="{{ route('users.index') }}">
                        <img src="{{ asset('images/back.png') }}" alt="back">
                        Back
                    </a>
                </div>
            </div>
            <div>
            </div>
        </div>
    </div>
</div>
@endsection
