<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Models\User;
use App\Models\Project;
use App\Models\Enrolment;
use App\Models\Attachment;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\EnrolmentController;
use App\Http\Controllers\AttachmentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::resource('user', UserController::class);
Route::resource('project', ProjectController::class);
Route::resource('enrolment', EnrolmentController::class);

// Route to show a list of industry partners
Route::get('/', [UserController::class, 'index'])->name('users.index');

// Route to show a list of projects offered by a specific industry partner
Route::get('/users/{user}', [UserController::class, 'show'])->name('users.show');

// Route to show project details
Route::get('/projects/{project}', [ProjectController::class, 'show'])->name('projects.show');

// Route to show the project creation form
Route::get('/projects/create', [ProjectController::class, 'create'])->name('projects.create');

// Route to handle the submission of the project creation form
Route::post('/projects', [ProjectController::class, 'store'])->name('projects.store');

// Route to show the project editing form
Route::get('/projects/{project}/edit', [ProjectController::class, 'edit'])->name('projects.edit');

// Route to handle the submission of the project editing form
Route::patch('/projects/{project}', [ProjectController::class, 'update'])->name('projects.update');

// Route to handle the deletion of a project
Route::delete('/projects/{project}', [ProjectController::class, 'destroy'])->name('projects.destroy');

// Route to show a list of all projects
Route::get('/projects-list', [ProjectController::class, 'projectsList'])->name('projects.list');

// Route for displaying the project application form
Route::get('/projects/{project}/apply', [ProjectController::class, 'showApplicationForm'])->name('projects.apply');

// Route for handling the project application form submission
Route::post('/projects/{project}/apply', [ProjectController::class, 'submitApplication'])->name('projects.submitApplication');

// Sample route with a placeholder controller method
Route::get('/some-route', [ProjectController::class, 'methodName']);

// Route for handling the storing of files
Route::post('/projects/{project}/attachments', [AttachmentController::class, 'store'])->name('projects.attachments.store');

// Route for handling the download of files
Route::get('/attachments/{attachment}/download', [AttachmentController::class, 'download'])->name('attachments.download');
Route::get('/attachments/download/{attachment}', 'AttachmentController@download')->name('attachments.download');


// route to view documentation page
Route::get('documentation', function () {
    return view('documentation');
});
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
