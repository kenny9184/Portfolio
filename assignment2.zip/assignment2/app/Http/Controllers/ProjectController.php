<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use App\Models\User;
use App\Models\Project;
use App\Models\Enrolment;
use App\Rules\UniqueProjectNameInOffering;
use App\Http\Controllers\Controller;


class ProjectController extends Controller
{

    function __construct(){
        $this->middleware('auth', ['except'=>['index', 'show']]);
        $this->middleware('check.user.type:industry_partner', ['only' => ['create', 'edit', 'destroy']]);
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('projects.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
        'title' => [
            'required',
            'min:5',
            'max:255',
            new UniqueProjectNameInOffering($request->trimester, $request->year),
        ],            
            'description' => 'required|string|min:3',
            'num_of_students' => 'required|integer|between:3,6',
            'year' => 'required|integer|between:2023,2024',
            'trimester' => 'required|integer|between:1,3',
            'attachments.*' => 'nullable|mimes:jpeg,png,jpg,pdf,doc,docx|max:2048',
        ], [
            'title.min' => 'The title must be at least :min characters.',
            'description.min' => 'The description must be at least :min words.',
            'num_of_students.between' => 'The number of students must be between :min and :max.',
            'year.between' => 'The year must be between :min and :max.',
            'trimester.between' => 'The trimester must be between :min and :max.',
        ]);
    
        // Create the project
        $project = auth()->user()->projects()->create([
            'title' => $request->input('title'),
            'description' => $request->input('description'),
            'num_of_students' => $request->input('num_of_students'),
            'year' => $request->input('year'),
            'trimester' => $request->input('trimester'),
        ]);
    
        // Handle file uploads (multiple attachments)
        if ($request->hasFile('attachments')) {
            $attachmentPaths = [];
    
            foreach ($request->file('attachments') as $attachment) {
                // Store each attachment and collect the file paths
                $attachmentPath = $attachment->store('project_attachments', 'public');
                $attachmentPaths[] = $attachmentPath;
            }
    
            // Update the project's attachments column with an array of file paths
            $project->attachments = $attachmentPaths;
            $project->save();
        }
    
        return redirect()->route('projects.show', ['project' => $project->id])->with('success', 'Project created successfully.');
    }
    /**
     * Display the specified resource.
     */
    public function show(Project $project)
{
    $project->load('studentProjects', 'attachments');

    $students = $project->studentProjects;
    $attachments = $project->attachments;

    return view('projects.show', compact('project', 'students', 'attachments'));
}

    

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $project = Project::findOrFail($id);
        return view('projects.edit', compact('project'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Project $project)
    {
        // Validate the form data
        $request->validate([
            'title' => 'required|min:5|max:255',
            'description' => 'required|min:3',
            'num_of_students' => 'required|integer|between:3,6',
            'year' => 'required|integer|between:2023,2025',
            'trimester' => ['required', 'integer', Rule::in([1, 2, 3])],
        ], [
            // Custom error messages
            'title.min' => 'Title must be at least 5 characters.',
            'description.min' => 'Description must be at least 3 words.',
            'num_of_students.between' => 'Number of students must be between 3 and 6.',
            'year.between' => 'The year must be between 2023 and 2025.',
            'trimester.in' => 'Invalid trimester. Must be 1, 2, or 3.',
        ]);

        // Update the project with the new data
        $project->update($request->all());

        // Redirect to the project details page
        return redirect()->route('projects.show', ['project' => $project->id]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Project $project)
    {
        // Check if there are students applied to the project
        if ($project->studentProjects()->count() > 0) {
            return redirect()->route('projects.show', ['project' => $project->id])->with('error', 'Cannot delete the project with applied students.');
        }
    
        // Get the associated user (IP) before deleting the project
        $user = $project->user;
    
        // Check if the user is available
        if (!$user) {
            return redirect()->route('projects.index')->with('error', 'User not found.');
        }
    
        // Delete the project
        $project->delete();
    
        // Redirect to the user's show page
        return redirect()->route('users.show', ['user' => $user->id])->with('success', 'Project deleted successfully.');
    }    

    public function projectsList()
    {
        // Fetch projects grouped by year and trimester in reverse chronological order
        $projectsByOffering = Project::orderBy('year', 'desc')
            ->orderBy('trimester', 'desc')
            ->get()
            ->groupBy(['year', 'trimester']);

        return view('projects.list', compact('projectsByOffering'));
        }

    public function showApplicationForm($projectId)
    {
        // Retrieve the project based on $projectId
        $project = Project::findOrFail($projectId);
    
        // You can pass any necessary data to the view
        return view('projects.apply', ['project' => $project]);
    }

    public function submitApplication(Request $request, $projectId)
    {
        // Retrieve the project based on $projectId
        $project = Project::findOrFail($projectId);
    
        // Validate the form data
        $request->validate([
            'justification' => 'required|max:255',
        ]);
    
        // Attach the authenticated user to the project with justification
        auth()->user()->studentProjects()->attach($project->id, ['justification' => $request->justification]);

        // Redirect back to the project details page with a success message
        return redirect()->route('projects.show', ['project' => $project->id])->with('message', 'Application submitted successfully.');
    }
    
}
    

