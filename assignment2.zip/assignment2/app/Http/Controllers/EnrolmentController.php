<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Project;
use App\Models\Enrolment;

class EnrolmentController extends Controller
{
    public function apply(Request $request, $projectId)
    {
        $user = auth()->user();
    
        // Check if the user has already applied to 3 projects
        if ($user->enrolments()->count() >= 3) {
            return redirect()->back()->with('error', 'You can only apply to a maximum of 3 projects.');
        }
    
        // Check if the user has already applied to the same project
        if ($user->enrolments()->where('project_id', $projectId)->exists()) {
            return redirect()->back()->with('error', 'You have already applied to this project.');
        }
    
        // Check if the user has already applied to 3 projects after the current application
        if ($user->enrolments()->count() + 1 > 3) {
            return redirect()->back()->with('error', 'You can only apply to a maximum of 3 projects.');
        }
    
        // Create the enrolment
        Enrolment::create([
            'project_id' => $projectId,
            'user_id' => $user->id,
            'justification' => $request->input('justification'),
        ]);
    
        return redirect()->back()->with('success', 'Application submitted successfully.');
    }
    

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

}
