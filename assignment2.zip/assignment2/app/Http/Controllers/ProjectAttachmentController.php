<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProjectAttachment;
use App\Models\User;
use App\Models\Project;
use App\Models\Enrolment;

class AttachmentController extends Controller
{
    public function store(Request $request, $projectId)
    {
        // Handle attachment upload logic
        $filePath = $request->file('attachment')->store('uploads', 'public');
    
        // Save attachment details to the database with project_id
        ProjectAttachment::create([
            'project_id' => $projectId,
            'path' => $filePath,
            'type' => $request->file('attachment')->getClientOriginalExtension(),
        ]);
    
        // Redirect back to the project details page
        return redirect()->route('projects.show', ['project' => $projectId])->with('success', 'Attachment uploaded successfully.');
    }
    
    public function download($attachmentId)
    {
        $attachment = ProjectAttachment::findOrFail($attachmentId);
    
        $Path = $attachment->path;
    
        // Adjust the storage disk and directory based on your setup
        $path = storage_path("app/{$attachment->path}");

        return response()->download($path, $attachment->filename);
    }
}
