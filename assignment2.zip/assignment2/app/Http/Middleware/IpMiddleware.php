<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class IpMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
      // Check if the user is logged in
    if (auth()->check()) {
        // Check if the user has the role of an industry partner
        if (auth()->user()->user_type === 'industry_partner') {
            return $next($request);
        }
    }

    // If not logged in or not an industry partner, redirect or handle as needed
    return redirect('/')->with('error', 'You do not have permission to access this resource.');
    }
}
