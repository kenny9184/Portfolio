<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use App\Models\Project;

class UniqueProjectNameInOffering implements Rule
{
    private $trimester;
    private $year;

    public function __construct($trimester, $year)
    {
        $this->trimester = $trimester;
        $this->year = $year;
    }

    public function passes($attribute, $value)
    {
        return !Project::where('title', $value)
            ->where('trimester', $this->trimester)
            ->where('year', $this->year)
            ->exists();
    }

    public function message()
    {
        return 'Choose a new title for this since there is already a project with that title in the same year and trimester.';
    }
}
