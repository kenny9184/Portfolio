<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Enrolment extends Model
{
    use HasFactory;

    protected $fillable = [
        'project_id',
        'user_id', // Change 'student_id' to 'user_id'
        'justification',
    ];

    // Define the M:1 relationship with the project
    public function project()
    {
        return $this->belongsTo(Project::class);
    }

    // Define the M:1 relationship with the user (which includes students and industry partners)
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
