<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'description',
        'num_of_students',
        'year',
        'trimester',
        'attachment',
        'user_id'
    ];

    // define the M:1 relationship with industrypartner

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function studentProjects()
    {
        return $this->belongsToMany(User::class, 'enrolments')->withPivot('justification')->where('user_type', 'student');
    }    

    public function attachments()
    {
        return $this->hasMany(ProjectAttachment::class);
    }
}
