<?php $__env->startSection('title', 'Apply for Project'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            <div class="left-section">
                Application for <?php echo e($project->title); ?>

            </div>
            <div class="right-section">
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(ucfirst(str_replace('_', ' ', Auth::user()->user_type))); ?>: <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
            </div>
        </div>
        <div class="info">
            <form method="post" action="<?php echo e(route('projects.apply', ['project' => $project->id])); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="justification">Justification:</label>
                    <textarea id="justification" name="justification" rows="4" cols="50" required placeholder="Why do you want to work on this project?"></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn">Submit Application</button>
                </div>
            </form>

            <?php if(session('error')): ?>
                <div id="error-alert" class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>


            <div class="post-actions">
                <a class="action-link" href="<?php echo e(route('projects.show',['project' => $project->id])); ?>">
                    <img src="<?php echo e(asset('images/back.png')); ?>" alt="back">
                    Back
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/projects/apply.blade.php ENDPATH**/ ?>