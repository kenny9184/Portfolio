<?php $__env->startSection('title', 'Edit Project'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="main_content">
            <div class="header">
                <div class="left-section">
                    Edit: <?php echo e($project->title); ?>

                </div>
                <div class="right-section">
                    <?php if(auth()->guard()->check()): ?>
                        <?php echo e(ucfirst(str_replace('_', ' ', Auth::user()->user_type))); ?>: <?php echo e(Auth::user()->name); ?>

                    <?php endif; ?>
                </div>
            </div>
            <div class="info">
                <form action="<?php echo e(route('projects.update', ['project' => $project->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <div class="form-group">
                        <label class="label" for="title">Title:</label>
                        <input class="input" type="text" id="title" name="title" value="<?php echo e(old('title', $project->title)); ?>" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="label" for="description">Description:</label>
                        <textarea class="input" id="description" name="description" required><?php echo e(old('description', $project->description)); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="label" for="num_of_students">Number of Students:</label>
                        <input class="input" type="number" id="num_of_students" name="num_of_students" value="<?php echo e(old('num_of_students', $project->num_of_students)); ?>" required>
                        <?php $__errorArgs = ['num_of_students'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="label" for="year">Year:</label>
                        <input class="input" type="number" id="year" name="year" value="<?php echo e(old('year', $project->year)); ?>" required>
                        <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="label" for="trimester">Trimester:</label>
                        <input class="input" type="number" id="trimester" name="trimester" value="<?php echo e(old('trimester', $project->trimester)); ?>" required>
                        <?php $__errorArgs = ['trimester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="button">Update Project</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/projects/edit.blade.php ENDPATH**/ ?>