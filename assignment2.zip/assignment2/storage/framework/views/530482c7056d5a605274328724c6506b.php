<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            <div class="left-section">
                List of Industry Partners
            </div>
            <div class="right-section">
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(ucfirst(str_replace('_', ' ', Auth::user()->user_type))); ?>: <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
            </div>
        </div>
        <div class="info">
            <div class="list">
                <ul class="post-list">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="post-item">
                        <a href="user/<?php echo e($user->id); ?>"><h2><?php echo e($user->name); ?></h2> 
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/users/index.blade.php ENDPATH**/ ?>