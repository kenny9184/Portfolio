<?php $__env->startSection('title', $project->title . ' Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="main_content">
            <div class="header">
                <div class="left-section">
                    <?php echo e($project->title); ?> Details
                </div>
                <div class="right-section">
                    <?php if(auth()->guard()->check()): ?>
                        <?php echo e(ucfirst(str_replace('_', ' ', Auth::user()->user_type))); ?>: <?php echo e(Auth::user()->name); ?>

                    <?php endif; ?>
                </div>
            </div>
            <div class="info">
                <div class="project-details">
                    <h4>Description: <?php echo e($project->description); ?></h4><br>
                    <h4>Number of Students: <?php echo e($project->num_of_students); ?></h4><br>
                    <h4>Year: <?php echo e($project->year); ?></h4><br>
                    <h4>Trimester: <?php echo e($project->trimester); ?></h4><br>
                    <h4>Offered by: <?php echo e($project->user->name); ?></h4><br>
                </div>
                <div class="attachments">
                    <h2>Attachments</h2>

                    <?php if($attachments->count() > 0): ?>
                        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($attachment->type === 'image'): ?>
                                <img src="<?php echo e(asset($attachment->path)); ?>" alt="Project Image">
                            <?php elseif($attachment->type === 'pdf'): ?>
                                <a href="<?php echo e(route('attachments.download', ['attachment' => $attachment->id])); ?>" target="_blank">Download PDF</a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>No attachments available for this project.</p>
                    <?php endif; ?>
                </div>
                
                <div class="applied-students">
                    <h2>Applied Students</h2>
                    <?php if($project->studentProjects && $project->studentProjects->count() > 0): ?>
                        <?php $__currentLoopData = $project->studentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="applied-student">
                                <h4><?php echo e($student->name); ?></h4>
                                <h5>Justification: <?php echo e($student->pivot->justification); ?></h5>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>No students have applied for this project.</p>
                    <?php endif; ?>
                </div>
                <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                
                <div class="post-actions">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->user_type === 'student'): ?>
                            <a class="action-link" href="<?php echo e(route('projects.apply', ['project' => $project->id])); ?>">
                                <img class="navicon" src="<?php echo e(asset('images/apply.png')); ?>" alt="Apply">
                                Apply for this project
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                    <br>
                    <a class="action-link" href="<?php echo e(route('users.show', ['user' => $project->user_id])); ?>">
                        <img class="navicon" src="<?php echo e(asset('images/back.png')); ?>" alt="Back">
                        Back
                    </a>
                    <?php if(auth()->check() && auth()->user()->user_type === 'industry_partner' && $project->user_id === auth()->user()->id): ?>
                        <a class="action-link edit-btn" href="<?php echo e(route('projects.edit', ['project' => $project->id])); ?>">
                            <img class="navicon" src="<?php echo e(asset('images/edit.png')); ?>" alt="Edit">
                            Edit project
                        </a>
                        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($attachment->type === 'image'): ?>
                                <img src="<?php echo e(asset($attachment->path)); ?>" alt="Project Image">
                            <?php elseif($attachment->type === 'pdf'): ?>
                                <a href="<?php echo e(route('attachments.download', ['attachment' => $attachment->id])); ?>" target="_blank">Download PDF</a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <form action="<?php echo e(url("project/$project->id")); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="action-link delete-btn">
                            <img class="navicon" src="<?php echo e(asset('images/delete.png')); ?>" alt="Delete">
                            Delete project
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/projects/show.blade.php ENDPATH**/ ?>