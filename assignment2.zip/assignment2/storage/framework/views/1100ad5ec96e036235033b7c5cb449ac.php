<?php $__env->startSection('title', 'Projects List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="main_content">
            <div class="header">
                <div class="left-section">
                    List of Projects
                </div>
                <div class="right-section">
                    <?php if(auth()->guard()->check()): ?>
                        <?php echo e(ucfirst(str_replace('_', ' ', Auth::user()->user_type))); ?>: <?php echo e(Auth::user()->name); ?>

                    <?php endif; ?>
                </div>
            </div>
            <div class="info">
                <div class="list">
                <?php $__currentLoopData = $projectsByOffering; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offering => $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($offering); ?></h2>

    <ul class="project-group">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $projectCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="post-item">
                    <a href="<?php echo e(route('projects.show', ['project' => $project->id])); ?>">
                        <h3><?php echo e($project->title); ?></h3>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/projects/list.blade.php ENDPATH**/ ?>