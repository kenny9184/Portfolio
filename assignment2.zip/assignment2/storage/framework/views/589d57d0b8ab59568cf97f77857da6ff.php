<div class="wrapper">
    <div class="sidebar">
        <h2>WIL</h2>
        <ul>
            <li><a href="<?php echo e(url("/")); ?>" class="nav-link"><img class="navicon" src="<?php echo e(asset('images/home.png')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('projects.list')); ?>" class="nav-link"><img class="navicon" src="<?php echo e(asset('images/list.png')); ?>">Projects List</a></li>
            <li><a href="<?php echo e(url("documentation")); ?>" class="nav-link"><img class="navicon" src="<?php echo e(asset('images/document.png')); ?>">Documentation</a></li>
            <?php if(auth()->check() && auth()->user()->user_type === 'industry_partner'): ?>
                <li><a href="<?php echo e(route('project.create')); ?>" class="nav-link"><img class="navicon" src="<?php echo e(asset('images/add.png')); ?>">Create project</a></li>
            <?php endif; ?>                 
            <?php if(auth()->guard()->check()): ?>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <img class="navicon" src="<?php echo e(asset('images/logout.png')); ?>">Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            <?php else: ?>
                <li><a href="<?php echo e(route('login')); ?>" class="nav-link"><img class="navicon" src="<?php echo e(asset('images/user.png')); ?>">Log in</a></li>
                <?php if(Route::has('register')): ?>
                    <li><a href="<?php echo e(route('register')); ?>" class="nav-link"><img class="navicon" src="<?php echo e(asset('images/add.png')); ?>">Register</a></li>
                <?php endif; ?>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/layouts/nav.blade.php ENDPATH**/ ?>