<?php $__env->startSection('title', 'Documentation'); ?>

<?php $__env->startSection('content'); ?>
<div class ="wrapper">
    <div class="main_content">
        <div class="header">Welcome to the Documentation Page</div>
            <div class="info">
                <h1>ERD</h1>
                <br>
                <img src="<?php echo e(asset('images/erd.png')); ?>" alt="ERD Image">
                <br>
                <h1>2</h1>
                    <p>I was able to complete tasks 1 – 9 with success, task 10 and 11 
                        were partially completed. The rest was incompleted due to time and 
                        misunderstanding
                    </p>
                <br>
                <h1>3</h1>
                    <p>Overall, I am somewhat happy with the progress I made throughout the project.
                        In my opnion, i thought that the less time frame compared to previous assignment<br>
                        gave me a lot more stress in completing tasks.<br> I got started with brainstorming erds and
                        <br> trying to form migrations tables, which was the biggest issue for me since i kept messing <br>
                        the foreign keys. To fixed that, i had to keep rewatching the lecture videos and <br> search online for help.
                        To test code I mainly used ai to help spot my erorrs and mistakes as well as some css. If i was to start again i would force myself to
                        not give up or forget about what i am <br> attempting everytime i face an error, since thats probably the worst mistake i made.
                    </p>
                <a href= "https://chat.openai.com/share/2efd442b-6810-4e4e-9961-0006981bb2af"><h2>References</h2>
</a>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/documentation.blade.php ENDPATH**/ ?>