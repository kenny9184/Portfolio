<?php $__env->startSection('title', $user->name . ' Projects'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            <div class="left-section">
                <?php echo e($user->name); ?>'s Projects
            </div>
            <div class="right-section">
                <?php if(auth()->guard()->check()): ?>
                    <?php echo e(ucfirst(str_replace('_', ' ', Auth::user()->user_type))); ?>: <?php echo e(Auth::user()->name); ?>

                <?php endif; ?>
            </div>
        </div>
        <div class="info">
            <h2>Email: <?php echo e($user->email); ?></h2><br>
            <div class="list">
                <ul class="post-list">
                    <?php $__currentLoopData = $user->projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="post-item">
                            <a href="<?php echo e(route('projects.show', ['project' => $project->id])); ?>">
                                <h2><?php echo e($project->title); ?></h2>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div class="post-actions">
                    <a class="action-link" href="<?php echo e(route('users.index')); ?>">
                        <img src="<?php echo e(asset('images/back.png')); ?>" alt="back">
                        Back
                    </a>
                </div>
            </div>
            <div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment2/resources/views/users/show.blade.php ENDPATH**/ ?>