@extends('layouts.master')

@section('title', 'Home')

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            Unique Users
        </div>
        <div class="info">
            <div class="list">
                <ul class="post-list">
                    @foreach ($uniqueAuthors as $author)
                    <li class="post-item">
                        <a href="{{url("author_posts/$author->author")}}">
                            <h2>{{$author->author}} </h2> 
                        </a>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection



