@extends('layouts.master')

@section('title', 'Update Post')

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">Edit: {{$post->title}}</div>
        <div class="info">
            <h1>Edit Post</h1>
            <!-- form for updating a post -->
            <form class="update-form" method="post" action="{{url("update_post_action")}}">
                @csrf <!-- generates a token for each user session, when form is submitted laravel checks if the token in the request matches the stored user session -->
                <!-- hidden input to send post ID -->                
                <input type="hidden" name="id" value="{{$post->id}}"> 
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" id="title" class="form-control"> 
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea name="message" id="message" class="form-control" rows="4"></textarea> 
                </div>
                <button type="submit" class="btn btn-primary">Update Post</button> 
            </form>
        </div>
    </div>
</div>
@endsection
