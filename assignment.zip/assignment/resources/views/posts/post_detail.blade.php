@extends('layouts.master')

@section('title', $post->title)

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">{{$post->title}}</div>
        <div class="info">
            <h3>Author: {{$post->author}}</h3>
            <p>Message: {{$post->message}}</p>
            <p>Date Posted: {{$post->datepost}}</p>
            
            <div class="comments">
                <h3>Comments:</h3>
                <ul>
                    @foreach ($post->comments as $comment)
                        <li>
                            <p><h3>{{$comment->commenter}}</h3> Commented:  {{$comment->message}} <br> On: {{$comment->datecommented}}</p>
                            
                            <!-- gets and displays child comments -->
                            @php
                                $childComments = DB::table('child_comment')
                                    ->where('comment_id', $comment->id)
                                    ->get();
                            @endphp
                            @if (count($childComments) > 0)
                                <ul>
                                    @foreach ($childComments as $childComment)
                                        <li>
                                            <p><h3>{{$childComment->commenter}}</h3> Commented:  {{$childComment->message}} <br> On: {{$childComment->datecommented}}</p>
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                            
                            <!-- form to submit a child comment -->
                            <div class="comment-form">
                                <h4>Add a Child Comment</h4>
                                <form method="post" action="{{url("add_child_comment_action")}}">
                                    @csrf
                                    <input type="hidden" name="post_id" value="{{$post->id}}">
                                    <input type="hidden" name="parent_comment_id" value="{{$comment->id}}">
                                    <p>
                                        <label>Your Name</label>
                                        <input type="text" name="commenter">
                                    </p>
                                    <p>
                                        <label>Your Comment</label>
                                        <textarea name="message"></textarea>
                                    </p>
                                    <input type="submit" value="Add Comment">
                                </form>
                            </div>
                        </li>
                    @endforeach
                </ul>
            </div>
            
            <div class="post-actions">
                <a class="action-link" href="{{url("update_post/$post->id")}}">
                    <img class="navicon" src="{{asset('images/edit.png')}}" alt="Edit">
                    Update post
                </a>
                <a class="action-link" href="{{url("delete_post/$post->id")}}">
                    <img class="navicon" src="{{asset('images/delete.png')}}" alt="Delete">
                    Delete post
                </a>
            </div>
            <!-- form to submit a comment -->
            <div class="comment-form">
                <h2>Add a Comment</h2>
                <form method="post" action="{{url("add_comment_action")}}">
                    @csrf
                    <input type="hidden" name="post_id" value="{{$post->id}}">
                    <p>
                        <label>Your Name</label>
                        <input type="text" name="commenter">
                    </p>
                    <p>
                        <label>Your Comment</label>
                        <textarea name="message"></textarea>
                    </p>
                    <input type="submit" value="Add Comment">
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
