@extends('layouts.master')

@section('title', 'Home')

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            Welcome to BetaMeta
        </div>
        <div class="info">
            <h1>Trending Posts!</h1>
            <div class="list">
                @if ($posts)
                <ul class="post-list">
                    @foreach($posts as $post)
                    <li class="post-item">
                        <a href="{{url("post_detail/$post->id")}}">
                            <h2>{{$post->title}}</h2>
                            <h3 class="author">By {{$post->author}}</h3>
                            <h5>Posted on {{$post->datepost}}</h5>
                            <h5>Comments: {{$post->comment_count}}</h5>
                        </a>
                    </li>
                    @endforeach
                </ul>
                @else
                <p>No posts found</p>
                @endif
            </div>
            <div class="add-post-form">
                <h2>Create a Post</h2>
                <form method="post" action="{{url("add_post_action")}}"> 
                    @csrf <!-- generates a token for each user session, when form is submitted laravel checks if the token in the request matches the stored user session -->
                    <div class="form">
                        <label>Title</label>
                        <input type="text" name="title" class="form-control">
                        @if ($errors->has('title'))
                            {{$errors->first('title')}}
                        @endif
                    </div>
                    <div class="form">
                        <label>Author</label>
                        <input type="text" name="author" class="form-control">
                        @if ($errors->has('author'))
                            {{$errors->first('author')}}
                        @endif
                    </div>
                    <div class="form">
                        <label>Message</label>
                        <textarea type="text" name="message" class="form-control"></textarea>
                        @if ($errors->has('message'))
                            {{$errors->first('message')}}
                        @endif
                    </div>
                    <button type="submit" class="btn btn-primary">Post</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
