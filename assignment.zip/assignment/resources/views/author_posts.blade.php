@extends('layouts.master')

@section('title', 'Posts by Author')

@section('content')
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            Posts by Author: {{ $posts[0]->author }}
        </div>
        <div class="info">
            <h1>Posts</h1>
            <div class="list">
                <ul class="post-list">
                    @foreach ($posts as $post)
                    <li class="post-item">
                        <a href="{{ url("post_detail/$post->id") }}">
                            <h2>{{ $post->title }}</h2>
                            <h3 class="author">By {{ $post->author }}</h3>
                            <h5>Posted on {{ $post->datepost }}</h5>
                        </a>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection
