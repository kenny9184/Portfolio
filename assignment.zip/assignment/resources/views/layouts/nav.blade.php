<div class="wrapper">
    <div class="sidebar">
        <h2>BetaMeta</h2>
        <ul>
            <li><a href ="{{url("/")}}"><img class="navicon" src="{{asset('images/home.png')}}">Home</a></li>
            <li><a href="{{url("documentation")}}"><img class="navicon" src="{{asset('images/document.png')}}">Documentation</a></li>
            <li><a href="{{url("unique_authors")}}"><img class="navicon" src="{{asset('images/user.png')}}">Unique Authors</a></li>
        </ul>

        <div class="social_media">
            <a href="https://twitter.com/" target="_blank"><img class="navsocial" src="{{ asset('images/twitter.png') }}"></a>
            <a href="https://instagram.com/" target="_blank"><img class="navsocial" src="{{ asset('images/insta.png') }}"></a>
            <a href="https://www.facebook.com/" target="_blank"><img class="navsocial" src="{{ asset('images/fb.png') }}"></a>
            <a href="https://www.snapchat.com/" target="_blank"><img class="navsocial" src="{{ asset('images/snap.png') }}"></a>
        </div>
    </div>
</div>
