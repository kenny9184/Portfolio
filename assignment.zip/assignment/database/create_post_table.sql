DROP TABLE IF EXISTS post;
CREATE TABLE post (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(100) NOT NULL,
    author VARCHAR(50) NOT NULL,
    message text default '',
    datepost DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO post (title, author, message) VALUES
    ("I read a book", "John Smith", "New book was awesome!"),
    ("PHP is so cool", "Arthur Morgan", "I used laravel. It was a hit!"),
    ("Tech Talk: Latest Gadgets", "Kanye West", "Will use these for sure!"),
    ("Fitness Journey Update", "Cristiano Ronaldo", "Reached a new personal record at the gym today."),
    ("Thoughts on AI", "Elon Musk", "Scary, really scary.");
