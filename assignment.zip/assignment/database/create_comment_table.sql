DROP TABLE IF EXISTS comment;
CREATE TABLE comment (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    message TEXT NOT NULL,
    datecommented DATETIME DEFAULT CURRENT_TIMESTAMP,
    post_id INTEGER NOT NULL,
    commenter VARCHAR(50),
    FOREIGN KEY (post_id) REFERENCES post (id) ON DELETE CASCADE
);

INSERT INTO comment (message, datecommented, post_id, commenter) VALUES
    ("Great post! I loved it.", "2023-08-15 10:00:00", 1, "Kanye West"),
    ("So interesting. Keep it up", "2023-08-16 14:30:00", 2, "Cristiano Ronaldo"),
    ("I agree, the camera quality is alright.", "2023-08-17 09:45:00", 3, "John Smith"),
    ("Where did you go to school", "2023-08-15 12:00:00", 1, "John Smith"),
    ("Nice!!!!", "2023-08-16 15:00:00", 2, "Elon Musk");
