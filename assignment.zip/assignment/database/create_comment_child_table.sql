DROP TABLE IF EXISTS child_comment;
CREATE TABLE child_comment (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    message TEXT NOT NULL,
    datecommented DATETIME DEFAULT CURRENT_TIMESTAMP,
    commenter VARCHAR(50),
    comment_id INTEGER NOT NULL,
    FOREIGN KEY (comment_id) REFERENCES comment (id) ON DELETE CASCADE
);


INSERT INTO child_comment (message, commenter, comment_id) VALUES
    ("I agree with your point.", "Sammy", 1),  
    ("Great observation!", "Rose", 2),      
    ("I had the same.", "Mike", 1),   
    ("Could you explain further?", "Jamie", 3),
    ("I disagree with this.", "Peter", 2);   
