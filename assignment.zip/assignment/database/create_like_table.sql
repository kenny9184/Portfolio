DROP TABLE IF EXISTS "like";
CREATE TABLE likes (
    id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    user_name VARCHAR(50) NOT NULL,
    post_id INTEGER NOT NULL,
    UNIQUE(user_name, post_id)
);

