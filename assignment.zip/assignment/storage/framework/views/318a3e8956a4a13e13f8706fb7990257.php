<div class="wrapper">
    <div class="sidebar">
        <h2>BetaMeta</h2>
        <ul>
            <li><a href ="<?php echo e(url("/")); ?>"><img class="navicon" src="<?php echo e(asset('images/home.png')); ?>">Home</a></li>
            <li><a href="<?php echo e(url("documentation")); ?>"><img class="navicon" src="<?php echo e(asset('images/document.png')); ?>">Documentation</a></li>
            <li><a href="<?php echo e(url("unique_authors")); ?>"><img class="navicon" src="<?php echo e(asset('images/user.png')); ?>">Unique Authors</a></li>
        </ul>

        <div class="social_media">
            <a href="https://twitter.com/" target="_blank"><img class="navsocial" src="<?php echo e(asset('images/twitter.png')); ?>"></a>
            <a href="https://instagram.com/" target="_blank"><img class="navsocial" src="<?php echo e(asset('images/insta.png')); ?>"></a>
            <a href="https://www.facebook.com/" target="_blank"><img class="navsocial" src="<?php echo e(asset('images/fb.png')); ?>"></a>
            <a href="https://www.snapchat.com/" target="_blank"><img class="navsocial" src="<?php echo e(asset('images/snap.png')); ?>"></a>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/webAppDev/assignment/resources/views/layouts/nav.blade.php ENDPATH**/ ?>