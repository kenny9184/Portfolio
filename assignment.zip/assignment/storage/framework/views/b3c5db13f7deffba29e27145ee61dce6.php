<?php $__env->startSection('title', 'Documentation'); ?>

<?php $__env->startSection('content'); ?>
<div class ="wrapper">
    <div class="main_content">
        <div class="header">Welcome to the Documentation Page</div>
            <div class="info">
                <h1>ERD</h1>
                <br>
                <img src="<?php echo e(asset('images/erd.png')); ?>" alt="ERD Image">
                <br>
                <h1>2</h1>
                    <p>I was able to complete tasks 1 – 15 excluding 14 successfully. 
                        For the two required tasks that were not completed, 
                        I had run into some trouble with understanding as well as having run out of time.
                    </p>
                <br>
                <h1>3</h1>
                    <p>Overall, I am very happy with the progress I made throughout the project as I have 
                        achieved far much more than what I had aimed for in the start. In the beginning I had 
                        started the assignment by <br>implementing some drafts of the erd from above, with many updates
                        to it throughout the process. The erd served as a basis of planning for me as I 
                        used it to make sure that entities had the correct attributes. <br> Afterwards, I had started 
                        off with template inheritance and the navigation so that I can ensure that I do not repeat myself. 
                        In terms of testing, during the first half, I continuously used dd vardump to <br>test whether if information 
                        was being sent over. A problem that I had encountered that had bothered me was with the styling with the nav 
                        bar. As I developed the nav early on, the future css styles which <br>were implemented after had overwritten some 
                        of the styling for the nav, causing the user to not have access to clicking on links on the nav. To fix 
                        that, I had <br>to troubleshoot the problem by testing and removing each bit of css related. I really would 
                        not change much for assignment 2 as I had managed my time efficiently.
                    </p>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/documentation.blade.php ENDPATH**/ ?>