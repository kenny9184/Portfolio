<?php $__env->startSection('title', 'Posts by Author'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            Posts by Author: <?php echo e($posts[0]->author); ?>

        </div>
        <div class="info">
            <h1>Posts</h1>
            <div class="list">
                <ul class="post-list">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="post-item">
                        <a href="<?php echo e(url("post_detail/$post->id")); ?>">
                            <h2><?php echo e($post->title); ?></h2>
                            <h3 class="author">By <?php echo e($post->author); ?></h3>
                            <h5>Posted on <?php echo e($post->datepost); ?></h5>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/author_posts.blade.php ENDPATH**/ ?>