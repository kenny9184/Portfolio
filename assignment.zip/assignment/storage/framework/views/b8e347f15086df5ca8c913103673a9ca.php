<?php $__env->startSection('title', 'Add Child Comment'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">Add Child Comment</div>
        <div class="info">
            <form method="post" action="<?php echo e(url('add_child_comment_action')); ?>">
                <?php echo csrf_field(); ?>
                <!-- Use the $parentCommentId variable in your view as needed -->
<h2>Add a Child Comment to Comment ID: <?php echo e($parentCommentId); ?></h2>
<!-- Rest of your child comment form -->

                <input type="hidden" name="parent_comment_id" value="<?php echo e($parentCommentId); ?>">
                <p>
                    <label>Your Name</label>
                    <input type="text" name="commenter">
                </p>
                <p>
                    <label>Your Comment</label>
                    <textarea name="message"></textarea>
                </p>
                <input type="submit" value="Add Comment">
            </form>
            <a href="<?php echo e(route('post_detail', ['id' => $postId])); ?>" class="back-link">Back to Post Detail</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/add_child_comment.blade.php ENDPATH**/ ?>