<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            Welcome to BetaMeta
        </div>
        <div class="info">
            <h1>Trending Posts!</h1>
            <div class="list">
                <?php if($posts): ?>
                <ul class="post-list">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="post-item">
                        <a href="<?php echo e(url("post_detail/$post->id")); ?>">
                            <h2><?php echo e($post->title); ?></h2>
                            <h3 class="author">By <?php echo e($post->author); ?></h3>
                            <h5>Posted on <?php echo e($post->datepost); ?></h5>
                            <h5>Comments: <?php echo e($post->comment_count); ?></h5>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php else: ?>
                <p>No posts found</p>
                <?php endif; ?>
            </div>
            <div class="add-post-form">
                <h2>Create a Post</h2>
                <form method="post" action="<?php echo e(url("add_post_action")); ?>"> 
                    <?php echo csrf_field(); ?> <!-- generates a token for each user session, when form is submitted laravel checks if the token in the request matches the stored user session -->
                    <div class="form">
                        <label>Title</label>
                        <input type="text" name="title" class="form-control">
                        <?php if($errors->has('title')): ?>
                            <?php echo e($errors->first('title')); ?>

                        <?php endif; ?>
                    </div>
                    <div class="form">
                        <label>Author</label>
                        <input type="text" name="author" class="form-control">
                        <?php if($errors->has('author')): ?>
                            <?php echo e($errors->first('author')); ?>

                        <?php endif; ?>
                    </div>
                    <div class="form">
                        <label>Message</label>
                        <textarea type="text" name="message" class="form-control"></textarea>
                        <?php if($errors->has('message')): ?>
                            <?php echo e($errors->first('message')); ?>

                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Post</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/home.blade.php ENDPATH**/ ?>