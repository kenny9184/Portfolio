<?php $__env->startSection('title', 'Update Post'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">Edit: <?php echo e($post->title); ?></div>
        <div class="info">
            <h1>Edit Post</h1>
            <form class="update-form" method="post" action="<?php echo e(url("update_post_action")); ?>">
                <?php echo csrf_field(); ?> 
                <input type="hidden" name="id" value="<?php echo e($post->id); ?>">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" name="title" id="title" class="form-control">
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea name="message" id="message" class="form-control" rows="4"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Update Post</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/posts/update_post.blade.php ENDPATH**/ ?>