<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header"><?php echo e($post->title); ?></div>
        <div class="info">
            <h3>Author: <?php echo e($post->author); ?></h3>
            <p>Message: <?php echo e($post->message); ?></p>
            <p>Date Posted: <?php echo e($post->datepost); ?></p>
            
            <div class="comments">
                <h3>Comments:</h3>
                <ul>
                    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <p><h3><?php echo e($comment->commenter); ?></h3> Commented:  <?php echo e($comment->message); ?> <br> On: <?php echo e($comment->datecommented); ?></p>
                            
                            <!-- Retrieve and display child comments -->
                            <?php
                                $childComments = DB::table('child_comment')
                                    ->where('comment_id', $comment->id)
                                    ->get();
                            ?>
                            <?php if(count($childComments) > 0): ?>
                                <ul>
                                    <?php $__currentLoopData = $childComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <p><h3><?php echo e($childComment->commenter); ?></h3> Commented:  <?php echo e($childComment->message); ?> <br> On: <?php echo e($childComment->datecommented); ?></p>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            
                            <!-- form to submit a child comment -->
                            <div class="comment-form">
                                <h4>Add a Child Comment</h4>
                                <form method="post" action="<?php echo e(url("add_child_comment_action")); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                                    <input type="hidden" name="parent_comment_id" value="<?php echo e($comment->id); ?>">
                                    <p>
                                        <label>Your Name</label>
                                        <input type="text" name="commenter">
                                    </p>
                                    <p>
                                        <label>Your Comment</label>
                                        <textarea name="message"></textarea>
                                    </p>
                                    <input type="submit" value="Add Comment">
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
            <div class="post-actions">
                <a class="action-link" href="<?php echo e(url("update_post/$post->id")); ?>">
                    <img class="navicon" src="<?php echo e(asset('images/edit.png')); ?>" alt="Edit">
                    Update post
                </a>
                <a class="action-link" href="<?php echo e(url("delete_post/$post->id")); ?>">
                    <img class="navicon" src="<?php echo e(asset('images/delete.png')); ?>" alt="Delete">
                    Delete post
                </a>
            </div>
            <!-- form to submit a comment -->
            <div class="comment-form">
                <h2>Add a Comment</h2>
                <form method="post" action="<?php echo e(url("add_comment_action")); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                    <p>
                        <label>Your Name</label>
                        <input type="text" name="commenter">
                    </p>
                    <p>
                        <label>Your Comment</label>
                        <textarea name="message"></textarea>
                    </p>
                    <input type="submit" value="Add Comment">
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/posts/post_detail.blade.php ENDPATH**/ ?>