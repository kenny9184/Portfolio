<?php $__env->startSection('title'); ?>
  Post something new
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class ="wrapper">
    <div class="main_content">
        <div class="header">Create a Post</div>
            <div class="info">
            <h1>Enter the following</h1>
              <form method="post" action="<?php echo e(url("add_post_action")); ?>">
                <?php echo csrf_field(); ?>
                  <p>
                    <label>Title</label>
                    <input type="text" name="title">
                  </p>
                  <p>
                    <label>Author</label>
                    <input type="text" name="author">
                  </p>
                  <p>
                    <label>Message</label>
                    <textarea type="text" name="message"></textarea>
                  </p>
                    <input type="submit" value="Add">
              </form>
            </div>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/posts/add_post.blade.php ENDPATH**/ ?>