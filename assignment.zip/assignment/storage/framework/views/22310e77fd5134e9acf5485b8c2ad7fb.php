<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="main_content">
        <div class="header">
            Unique Users
        </div>
        <div class="info">
            <div class="list">
                <ul class="post-list">
                    <?php $__currentLoopData = $uniqueAuthors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="post-item">
                        <a href="<?php echo e(url("author_posts/$author->author")); ?>">
                            <h2><?php echo e($author->author); ?> </h2> 
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/unique_authors.blade.php ENDPATH**/ ?>