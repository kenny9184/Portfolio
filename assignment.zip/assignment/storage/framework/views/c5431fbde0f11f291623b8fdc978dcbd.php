<div class="main_content">
        <div class="header">Welcome!</div>
        <div class="info">
            <div>obsdxujiosedxbniouxsdn drftdrfcdrfctvg drfc ftgrfdtgrftgvfrtg rtfrfrfdvtg register_tick_function
                frtddrftrftdrfedjkmklmkjlim,tgyhghberredferd edr erderd  e werdfc rfdg drfct yhugyhtgygyhtytgh
                rftgdrftrftrftrftrtfrftgyh trf rt trf rfvtg 43eesd  dffg rftghghhjyuh ghbn yuhyhg  gyhu uyhg
            </div>
            <div>obsdxujiosedxbniouxsdn drftdrfcdrfctvg drfc ftgrfdtgrftgvfrtg rtfrfrfdvtg register_tick_function
                frtddrftrftdrfedjkmklmkjlim,tgyhghberredferd edr erderd  e werdfc rfdg drfct yhugyhtgygyhtytgh
                rftgdrftrftrftrftrtfrftgyh trf rt trf rfvtg 43eesd  dffg rftghghhjyuh ghbn yuhyhg  gyhu uyhg
            </div>
            <div>obsdxujiosedxbniouxsdn drftdrfcdrfctvg drfc ftgrfdtgrftgvfrtg rtfrfrfdvtg register_tick_function
                frtddrftrftdrfedjkmklmkjlim,tgyhghberredferd edr erderd  e werdfc rfdg drfct yhugyhtgygyhtytgh
                rftgdrftrftrftrftrtfrftgyh trf rt trf rfvtg 43eesd  dffg rftghghhjyuh ghbn yuhyhg  gyhu uyhg
            </div>
        </div>
    </div><?php /**PATH /var/www/html/webAppDev/assignment/resources/views/layouts/maincontent.blade.php ENDPATH**/ ?>