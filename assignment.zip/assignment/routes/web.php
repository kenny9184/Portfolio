<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// return the list of posts descdending by chronolgical time as well as counting the number of comments
Route::get('/', function () {
    $sql = "SELECT post.*, (SELECT COUNT(*) FROM comment WHERE comment.post_id = post.id) as comment_count FROM post ORDER BY datepost DESC";
    $posts = DB::select($sql);
    // return with the home view while sending $posts details to the view
    return view('home')->with('posts', $posts);
});

// recieve the details of a specific post by its ID
Route::get('post_detail/{id}', function($id){
    $post = get_post($id);
    // sends the posts details to post_detail view
    return view('posts.post_detail')->with('post', $post);
});

// route for the add post action once form is submitted 
Route::post('add_post_action', function () {
    // gets the title, author, message, and date from the form
    $title = request('title');
    $author = request('author');
    $message = request('message');
    $datepost = now();

    // input validation rules
    $errors = [];

    if (strlen($title) < 3) {
        $errors['title'] = 'Title must have at least 3 characters.';
    }

    if (preg_match('/\d/', $author)) {
        $errors['author'] = 'Author name must not contain numeric characters.';
    }

    if (str_word_count($message) < 5) {
        $errors['message'] = 'Message must have at least 5 words.';
    }

    if (count($errors) > 0) {
        // returns error message if error count is greater than 0
        return redirect(url("/"))
            ->withErrors($errors)
            ->withInput();
    }

    //  create a new post with data 
    $id = add_post($title, $author, $message, $datepost);
    // returns the home page with new post at top or shows the error message
    if ($id) {
        return redirect(url("/"));
    } else {
        die("Error while adding post");
    }
});

// gets the post details to for the update form
Route::get('update_post/{id}', function($id){
    $post = get_post($id);
    // pass post details to update post view
    return view('posts.update_post')->with('post', $post);
});

// deals with the form submission for updating a post
Route::post('update_post_action', function(){
    // gets the updated title, message, and post ID from the form
    $title = request('title');
    $message = request('message');
    $id = request('id');
    // applies the new updates to the post 
    // redirect user to the post detail page if successfully updated or shows error message if theres an issue with updating
    update_post($id, $title, $message);
    if ($id){
        return redirect(url("post_detail/$id"));
    } else {
        die("Error while updating post.");
    }
});

// deletes post based on its ID
Route::get('delete_post/{id}', function($id){
    delete_post($id);
    return redirect(url("/"));
});

// route to view documentation page
Route::get('documentation', function () {
    return view('documentation');
});

// route for adding a new comment to a post
Route::post('add_comment_action', function(){
    // retrieves the commenter name, comment message, and post ID from the form
    $commenter = request('commenter');
    $message = request('message');
    $post_id = request('post_id');
    // create a new comment with the provided data
    $id = add_comment($post_id, $commenter, $message);
    if ($id){
        // redirect to the post detail page if successfull
        return redirect(url("post_detail/$post_id"));
    } else {
        // if there is an issue with adding a comment, error message
        die("Error while adding comment");
    }
});

// route to get a list of unqiue users
Route::get('/unique_authors', function () {
    $uniqueAuthors = DB::select('SELECT DISTINCT author FROM post');
    return view('unique_authors')->with('uniqueAuthors', $uniqueAuthors);
});

// shows a lists of post made by a specific user
Route::get('/author_posts/{author}', function ($author) {
    // retruns list of posts by the specified user from post table
    $posts = DB::table('post')->where('author', $author)->get();
    
    // returns the author posts view with the releveant posts
    return view('author_posts')->with('posts', $posts);
})->name('author_posts');

// display child comments for a specific parent comment
Route::get('child_comments/{parent_comment_id}', function ($parent_comment_id) {
    $childComments = DB::table('child_comment')
        ->where('comment_id', $parent_comment_id)
        ->get();

    // pass child comments to a view to display them
    return view('child_comments')->with('childComments', $childComments);
})->name('child_comments');

// adds a child comment to a parent comment
Route::post('add_child_comment_action', function(){
    // retrieves parent_comment_id, commenter name, comment message, and post ID from the form
    $parent_comment_id = request('parent_comment_id');
    $commenter = request('commenter');
    $message = request('message');
    $post_id = request('post_id'); 

    // Add a new child comment with the provided data
    $id = add_child_comment($parent_comment_id, $commenter, $message);
    
    if ($id){
        // redirects to the post detail page 
        return redirect(url("post_detail/$post_id"));
    } else {
        die("Error while adding child comment");
    }
});

// function to add a new comment
function add_comment($post_id, $commenter, $message){
    // Use "?" placeholders to prevent SQL injection attacks as it is possible that the user could enter special characters which change the function of the SQL query.
    $sql = "insert into comment (post_id, commenter, message) values (?, ?, ?)";
    DB::insert($sql, array($post_id, $commenter, $message));
    $id = DB::getPdo()->lastInsertId();
    return($id);
}
// function to add post
function add_post($title, $author, $message, $datepost){
    // if input validation passes, post is added
    $sql = "insert into post (title, author, message, datepost) values (?, ?, ?, ?)";
    DB::insert($sql, array($title, $author, $message, $datepost));
    $id = DB::getPdo()->lastInsertId();
    return $id; 
}


// function to get post details by its ID
function get_post($id){
    $sql = "select * from post where id=?";
    $posts = DB::select($sql, array($id));
    if (count($posts) != 1){
        die("Something happened: $sql");
    }
    $post = $posts[0];
    // get comments related to the post and attaches it to the post
    $comments = get_comments_for_post($id);
    $post->comments = $comments;
    return $post;
}

// function to update a post
function update_post($id, $title, $message){
    $currentDate = now();
    $sql = "update post set title = ?, message = ?, datepost = ? where id = ?";
    DB::update($sql, [$title, $message, $currentDate, $id]);
}

// function to delete a post 
function delete_post($id){
    $sql = "delete from post where id = ?";
    DB::delete($sql, array($id));
}

// function to get comments using post id
function get_comments_for_post($post_id) {
    $sql = "select * from comment where post_id=?";
    $comments = DB::select($sql, array($post_id));
    return $comments;
}

// function to add a new child comment
function add_child_comment($parent_comment_id, $commenter, $message) {
    
    // insert the child comment into the child_comment table
    $currentDate = now();
    $sql = "INSERT INTO child_comment (commenter, message, datecommented, comment_id) VALUES (?, ?, ?, ?)";
    DB::insert($sql, [$commenter, $message, $currentDate, $parent_comment_id]);
    
    $id = DB::getPdo()->lastInsertId();
    
    return $id;
}
